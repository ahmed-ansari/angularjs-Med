app.service('AcceptRejectService', ['force', AcceptRejectService]);

function AcceptRejectService(processType){

	this.isApplicableForAcceptReject = function(userId) {
		
	};
}